package cs210;
import java.util.Scanner;
import java.lang.Math;
public abstract class HW1 {

	public static void main(String[] args) {
		Scanner newSc = new Scanner(System.in);
		System.out.println("Enter investment amount:  ");
		Double investment = newSc.nextDouble();
		System.out.println("Enter annual intrest rate:  ");
		Double monthyIR = newSc.nextDouble();
		System.out.println("Enter number of years:  ");
		Double years = newSc.nextDouble();
		Double part1 =  ((100 + monthyIR)/100);
		System.out.println(part1);
		Double part2 = (years);
		System.out.println(part2);
		Double part3 = Math.pow(part1,part2);
		System.out.println(part3);
		Double futureInvestment = (investment * part3);
		System.out.println("Accumulated Value is :" + futureInvestment);
		newSc.close();

	}

}
