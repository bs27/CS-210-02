
package sample;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;


public class copyOfWhat extends Application {






    public static void main(String[] args) {

        launch(args);

    }





    public void start(Stage primaryStage) {
        try {
            String[] cardList = {"A", "B", "C", "D", "E","A", "B", "C", "D", "E" };
            // , \"A of H\", \"2 of H\", \"3 of H\", \"4 of H\", \"5 of H\", \"6 of H\", \"7 of H\", \"8 of H\", \"9 of H\", \"10 of H\", \"J of H\", \"Q of H\", \"K of H\", \"A of H\", \"2 of H\", \"3 of H\", \"4 of H\", \"5 of H\", \"6 of H\", \"7 of H\", \"8 of H\", \"9 of H\", \"10 of H\", \"J of H\", \"Q of H\", \"K of H\", \"A of C\", \"2 of C\", \"3 of C\", \"4 of C\", \"5 of C\", \"6 of C\", \"7 of C\", \"8 of C\", \"9 of C\", \"10 of C\", \"J of C\", \"Q of C\", \"K of C\", \"A of C\", \"2 of C\", \"3 of C\", \"4 of C\", \"5 of C\", \"6 of C\", \"7 of C\", \"8 of C\", \"9 of C\", \"10 of C\", \"J of C\", \"Q of C\", \"K of C\", \"A of S\", \"2 of S\", \"3 of S\", \"4 of S\", \"5 of S\", \"6 of S\", \"7 of S\", \"8 of S\", \"9 of S\", \"10 of S\", \"J of S\", \"Q of S\", \"K of S\", \"A of S\", \"2 of S\", \"3 of S\", \"4 of S\", \"5 of S\", \"6 of S\", \"7 of S\", \"8 of S\", \"9 of S\", \"10 of S\", \"J of S\", \"Q of S\", \"K of S
            ArrayList<String> list = new ArrayList<>();
            for(int i = 0; i<10; i++) {
                list.add(cardList[i]);
            }
            ArrayList<String> lableList = new ArrayList<>();
            while (true) {
                int randomNum = ((int) (Math.random() * (list.size() - 1)));
                if (list.size() == 1) {
                    randomNum = 0;
                    lableList.add(list.get(randomNum));
                    break;
                } else {
                    lableList.add(list.get(randomNum));
                    list.remove(randomNum);
                }
            }

            GridPane grid = new GridPane();
            grid.setMaxSize(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE);
            grid.setPadding(new Insets(10, 10, 10, 10));
            grid.setVgap(10);
            grid.setHgap(10);
            int count = 0;
            int xAddress = 0;
            int yAdddress = 0;
            AtomicInteger oneAdd = new AtomicInteger();
            String arrayPair[] = new String[2];
            AtomicInteger score = new AtomicInteger();
            Label leaderboard = new Label("Matched Pairs");
            Label lastbox = new Label("Last Box Selected Contained...");
            String last = "N/A";
            Label lastL = new Label(last);
            Label scoreLabel = new Label(Integer.toString(score.get()));
            AtomicBoolean pair = new AtomicBoolean(false);
            Button button1 = new Button("   ");
            Button button2 = new Button("   ");
            Button button3 = new Button("   ");
            Button button4 = new Button("   ");
            Button button5 = new Button("   ");
            Button button6 = new Button("   ");
            Button button7 = new Button("   ");
            Button button8 = new Button("   ");
            Button button9 = new Button("   ");
            Button button10 = new Button("   ");
/*            Button button11 = new Button("   ");
            Button button12 = new Button("   ");
            Button button13 = new Button("   ");
            Button button14 = new Button("   ");
            Button button15  = new Button("   ");
            Button button16  = new Button("   ");
            Button button17  = new Button("   ");
            Button button18 = new Button("   ");
            Button button19 = new Button("   ");
            Button button20 = new Button("   ");*/
            StackPane stack1 = new StackPane();
            StackPane stack2 = new StackPane();
            StackPane stack3 = new StackPane();
            StackPane stack4 = new StackPane();
            StackPane stack5 = new StackPane();
            StackPane stack6 = new StackPane();
            StackPane stack7 = new StackPane();
            StackPane stack8 = new StackPane();
            StackPane stack9 = new StackPane();
            StackPane stack10 = new StackPane();
            AtomicBoolean hide = new AtomicBoolean(false);
/*            StackPane stack11 = new StackPane();
            StackPane stack12 = new StackPane();
            StackPane stack13 = new StackPane();
            StackPane stack14 = new StackPane();
            StackPane stack15 = new StackPane();
            StackPane stack16 = new StackPane();
            StackPane stack17 = new StackPane();
            StackPane stack18 = new StackPane();
            StackPane stack19 = new StackPane();
            StackPane stack20 = new StackPane();*/

            Label label1 = new Label(lableList.get(count));
            stack1.getChildren().addAll(label1,button1);
            GridPane.setConstraints(stack1, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label2 = new Label(lableList.get(count));
            stack2.getChildren().addAll(label2,button2);
            GridPane.setConstraints(stack2, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label3 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label3,button3);
            GridPane.setConstraints(stack3, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label4 = new Label(lableList.get(count));
            stack4.getChildren().addAll(label4,button4);
            GridPane.setConstraints(stack4, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label5 = new Label(lableList.get(count));
            stack5.getChildren().addAll(label5,button5);
            GridPane.setConstraints(stack5, xAddress, yAdddress);
            count++;
            xAddress = 0;
            yAdddress++;
            Label label6 = new Label(lableList.get(count));
            stack6.getChildren().addAll(label6,button6);
            GridPane.setConstraints(stack6, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label7 = new Label(lableList.get(count));
            stack7.getChildren().addAll(label7,button7);
            GridPane.setConstraints(stack7, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label8 = new Label(lableList.get(count));
            stack8.getChildren().addAll(label8,button8);
            GridPane.setConstraints(stack8, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label9 = new Label(lableList.get(count));
            stack9.getChildren().addAll(label9,button9);
            GridPane.setConstraints(stack9, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label10 = new Label(lableList.get(count));
            stack10.getChildren().addAll(label10,button10);
            GridPane.setConstraints(stack10, xAddress, yAdddress);
           /* count++;
            xAddress = 0;
            yAdddress++;*/
/*            Label label11 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label11,button11);
            GridPane.setConstraints(stack11, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label12 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label12,button12);
            GridPane.setConstraints(stack12, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label13 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label13,button13);
            GridPane.setConstraints(stack13, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label14 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label14,button14);
            GridPane.setConstraints(stack14, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label15 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label15,button15);
            GridPane.setConstraints(stack15, xAddress, yAdddress);
            count++;
            xAddress = 0;
            yAdddress++;
            Label label16 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label16,button16);
            GridPane.setConstraints(stack16, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label17 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label17,button17);
            GridPane.setConstraints(stack17, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label18 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label18,button18);
            GridPane.setConstraints(stack18, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label19 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label19,button19);
            GridPane.setConstraints(stack19, xAddress, yAdddress);
            count++;
            xAddress++;
            Label label20 = new Label(lableList.get(count));
            stack3.getChildren().addAll(label20,button20);
            GridPane.setConstraints(stack20, xAddress, yAdddress);*/
            grid.getChildren().addAll(stack1, stack2, stack3, stack4, stack5, stack6, stack7, stack8, stack9, stack10);
            //, stack11, stack12, stack13, stack14, stack15, stack16, stack17, stack18, stack19, stack20
            int v = 0;




            primaryStage.setTitle("The (Not as well known) Match Game");
            Label title = new Label("\"The (Not as well known) Match Game\"");
            Button welcomeButton = new Button("Start Game");

            Button instructButton = new Button("Read Instructions");
            VBox openingLayout = new VBox();
            openingLayout.getChildren().addAll(title, welcomeButton, instructButton);
            Scene openingScene = new Scene(openingLayout, 300, 300);
            String instructions = "Try and find the matching pairs to win!";
            instructButton.setOnAction(e -> error.display("Instructions", instructions));
            VBox scoreBoard = new VBox();
            scoreBoard.getChildren().addAll(leaderboard,scoreLabel,lastbox,lastL);
            BorderPane gameLayout = new BorderPane();
            gameLayout.setCenter(grid);
            gameLayout.setRight(scoreBoard);

            Scene sceneL = new Scene(gameLayout,400, 400);
            welcomeButton.setOnAction(e -> primaryStage.setScene(sceneL));

            primaryStage.setOnCloseRequest(e -> {
                e.consume();
                closeProgram(primaryStage);
            });
            button1.setOnAction(e->{ button1.setVisible(false);
            lastL.setText(label1.getText());
                if(pair.get() == false){
                  pair.set(true);
                  arrayPair[0] = label1.getText();
                  oneAdd.set(1);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label1.getText()){
                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label1.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button1.setVisible(true);
                    }
                }

            });
            button2.setOnAction(e->{
                button2.setVisible(false);
                lastL.setText(label2.getText());
                if(pair.get() == false){
                    pair.set(true);
                    arrayPair[0] = label2.getText();
                    oneAdd.set(2);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label2.getText()){
                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label2.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button2.setVisible(true);
                    }
                }

            });
            button3.setOnAction(e->{
                button3.setVisible(false);
                lastL.setText(label3.getText());
                if(pair.get() == false){
                    pair.set(true);
                    arrayPair[0] = label3.getText();
                    oneAdd.set(3);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label3.getText()){
                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label3.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button3.setVisible(true);
                    }
                }

            });
            button4.setOnAction(e->{
                button4.setVisible(false);
                lastL.setText(label4.getText());
                if(pair.get() == false){
                    pair.set(true);
                    arrayPair[0] = label4.getText();
                    oneAdd.set(4);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label4.getText()){
                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label4.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button4.setVisible(true);
                    }
                }

            });
            button5.setOnAction(e->{
                button5.setVisible(false);
                lastL.setText(label5.getText());
                if(pair.get() == false){
                    pair.set(true);
                    arrayPair[0] = label5.getText();
                    oneAdd.set(5);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label5.getText()){
                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label5.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button5.setVisible(true);
                    }
                }

            });
            button6.setOnAction(e->{
                button6.setVisible(false);
                lastL.setText(label6.getText());
                if(pair.get() == false){
                    pair.set(true);
                    arrayPair[0] = label6.getText();
                    oneAdd.set(6);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label6.getText()){
                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label6.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button6.setVisible(true);
                    }
                }

            });
            button7.setOnAction(e->{
                button7.setVisible(false);
                lastL.setText(label7.getText());
                if(pair.get() == false){
                    pair.set(true);
                    arrayPair[0] = label7.getText();
                    oneAdd.set(7);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label7.getText()){

                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label7.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button7.setVisible(true);
                    }
                }

            });
            button8.setOnAction(e->{
                button8.setVisible(false);
                lastL.setText(label8.getText());
                if(pair.get() == false){
                    pair.set(true);
                    arrayPair[0] = label8.getText();
                    oneAdd.set(8);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label8.getText()){
                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label8.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button8.setVisible(true);
                    }
                }

            });
            button9.setOnAction(e->{
                button9.setVisible(false);
                lastL.setText(label9.getText());
                if(pair.get() == false){
                    pair.set(true);
                    arrayPair[0] = label9.getText();
                    oneAdd.set(9);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label2.getText()){
                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label9.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button9.setVisible(true);
                    }
                }

            }); button10.setOnAction(e->{
                button10.setVisible(false);
                lastL.setText(label10.getText());
                if(pair.get() == false){
                    pair.set(true);
                    arrayPair[0] = label10.getText();
                    oneAdd.set(10);

                }else{
                    pair.set(false);
                    if(arrayPair[0] == label10.getText()){
                        hide.set(true);
                        score.getAndIncrement();
                        scoreLabel.setText(String.valueOf(score));
                        label10.setVisible(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        endProgram( primaryStage, score);
                    }else{
                        hide.set(false);
                        invisibleEnd(hide,oneAdd,label1, label2, label3, label4, label5, label6, label7, label8, label9, label10,button1, button2, button3, button4, button5, button6, button7, button8, button9, button10);
                        button10.setVisible(true);
                    }
                }

            });





            primaryStage.setScene(openingScene);
            primaryStage.show();



        }catch (Exception e){
            System.out.println(e);
        }
    }

    private void invisibleEnd(AtomicBoolean hide, AtomicInteger oneAdd, Label label1, Label label2, Label label3, Label label4, Label label5, Label label6, Label label7, Label label8, Label label9, Label label10, Button button1, Button button2, Button button3, Button button4, Button button5, Button button6, Button button7, Button button8, Button button9, Button button10){
        switch(String.valueOf(oneAdd)){
            case "1":
                if (hide.get()){
                    label1.setVisible(false);
                }else{

                    button1.setVisible(true);
                }
                break;
            case "2":
                if (hide.get() ){
                    label2.setVisible(false);
                }else{
                    button2.setVisible(true);
                }
                break;
            case "3":
                if (hide.get() ){
                    label3.setVisible(false);
                }else{
                    button3.setVisible(true);
                }
                break;
            case "4":
                if (hide.get() ){
                    label4.setVisible(false);
                }else{
                    button4.setVisible(true);
                }
                break;
            case "5":
                if (hide.get() ){
                    label5.setVisible(false);
                }else{
                    button5.setVisible(true);
                }
                break;
            case "6":
                if (hide.get() ){
                    label6.setVisible(false);
                }else{
                    button6.setVisible(true);
                }

                break;
            case "7":
                if (hide.get() ){
                    label7.setVisible(false);
                }else{
                    button7.setVisible(true);
                }
                break;
            case "8":
                if (hide.get() ){
                    label8.setVisible(false);
                }else{
                    button8.setVisible(true);
                }

                break;
            case "9":
                if (hide.get() ){
                    label9.setVisible(false);
                }else{
                    button9.setVisible(true);
                }

                break;
            case "10":
                if (hide.get() ){
                    label10.setVisible(false);
                }else{
                    button10.setVisible(true);
            }
                break;

        }


    }






    private void closeProgram( Stage primaryStage){
        boolean answer = confirm.display("Exit?","Leave Game?");
        if(answer){
            primaryStage.close();
        }
    }

    private void endProgram( Stage primaryStage, AtomicInteger score){
        if(score.get() == 5){
            Alert2.display("Victory!","You Win! Thanks for playing Ben Sottile's game the (Not as well known) Match Game");
            primaryStage.close();
        }
    }

}
class Alert2 {
    public static void display(String title, String message){
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setMinWidth(250);

        Label label = new Label();
        label.setText(message);
        Button closeButton = new Button("Thanks that was fun!");
        closeButton.setOnAction(e -> window.close());

        VBox layout = new VBox(10);
        layout.getChildren().addAll(label, closeButton);
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();
    }
}
class error {
    static boolean answer;

    public static boolean display(String title, String message){
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setMinWidth(250);

        Label label = new Label();
        label.setText(message);
        Button closeButton = new Button("Save Computer?");
        closeButton.setOnAction(e -> window.close());
        VBox layout = new VBox(10);
        layout.getChildren().addAll(label);
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();

        return answer;
    }
}
class confirm {
    static boolean answer;

    public static boolean display(String title, String message){
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setMinWidth(250);

        Label label = new Label();
        label.setText(message);
        Button closeButton = new Button("Save Computer?");
        closeButton.setOnAction(e -> window.close());

        Button yesButton = new Button("yes");
        Button noButton = new Button("no");

        yesButton.setOnAction(e-> {
            answer = true;
            window.close();
        });
        noButton.setOnAction(e-> {
            answer = false;
            window.close();
        });

        VBox layout = new VBox(10);
        layout.getChildren().addAll(label, yesButton,noButton);
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();

        return answer;
    }
}



