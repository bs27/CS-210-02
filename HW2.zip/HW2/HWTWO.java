package cs210;
import java.util.Scanner;

public abstract class HWTWO {
	
	
	public static double cToF(Double celcius) {
	//cToF(celsius) takes double Celsius returns double fahrenheit
	//(x�C � 9/5) + 32 = y F
		Double fahrenheit = (celcius * (9.0 / 5.0)) + 32;
		return fahrenheit;

}
	public static double ceToIn(Double centimeter) {
	//ceToIn(centimeter) takes double centimeter returns double inch
	//divide the length value by 2.54
		double inch = centimeter / 2.54;
		return inch;
	}
	public static double mToFoot(Double meter) {
	//mToFoot(meter) takes doubles meter and returns double foot
	//for an approximate result, multiply the length value by 3.281
		double foot = meter * 3.281;
		return foot;

}
	public static double msqTosqft(Double squareMeter) {
	//msqTosqft(squareMeter) takes double squareMeter returns double squareFoot
	// multiply the area value by 10.764
		double squarefoot = squareMeter * 10.764;
		return squarefoot;
}
	public static double lToG(Double liter) {
	//lToG(liter) tale double liter and returns double gallon
	//for an approximate result, divide the volume value by 3.785
		double gallon = liter/3.785;
		return gallon;
	}
	public static double gToO(Double gram) {
	//gToO(gram) takes double gram returns double ounce
	//for an approximate result, divide the mass value by 28.35
		double ounce = gram/28.35;
		return ounce;
	
	}
	public static double kToP(Double kilogram) {
	//kToP(kilogram) takes double kilogram returns double pound
	//for an approximate result, multiply the mass value by 2.205
		double pound = kilogram * 2.205;
		return pound;
	}
	public static void main(String[] args) {
		//Uses a scanner to get celsius , centimeter, meter, squareMeter,
		//liter, gram , kilogram measuerements (All will be doubles)
		Scanner newSc = new Scanner(System.in);
		System.out.println("Are your measuring units in that LAME metric system that the entire world uses?");
		System.out.println("It's TIME to get AMERICAN!!!");
		System.out.println("Welcome to Ben.Co's conversion calculator!!!");
		System.out.println("Celcius : ");
		double celcius = newSc.nextDouble();
		double fahrenheit = cToF(celcius);
		System.out.println("Centimeter :");
		double centimeter = newSc.nextDouble();
		double inch = ceToIn(centimeter);
		System.out.println("Meter :");
		double meter = newSc.nextDouble();
		double foot = mToFoot(meter);
		System.out.println("Square Meter : ");
		double squareMeter = newSc.nextDouble();
		double squareFoot = msqTosqft(squareMeter);
		System.out.println("Liter :");
		double liter = newSc.nextDouble();
		double gallon = lToG(liter);
		System.out.println("Gram  :");
		double gram = newSc.nextDouble();
		double ounce = gToO(gram);
		System.out.println("Kilogram  :");
		double kilogram = newSc.nextDouble();
		double pound =kToP(kilogram);
		//END: Print fahrenheit, inch, foot, squareFoot, gallom, ounce , pound

		System.out.println("European Units                  US Units");
		System.out.println("Celcius = " + celcius +"                    Fahrenheit = " + fahrenheit);
		System.out.println("Centimeter = " + centimeter +"                    Inch = " + inch);
		System.out.println("Meter = " + meter +"                    Foot = " + foot);
		System.out.println("Square Meter = " + squareMeter +"                    Square Foot = " + squareFoot);
		System.out.println("Liter = " + liter +"                    Gallon = " + gallon);
		System.out.println("Gram = " + gram +"                    Ounce = " + ounce);
		System.out.println("Kilogram = " + kilogram +"                    Pound = " + pound);
		
		
		
		
		
		
		
		

}

}
