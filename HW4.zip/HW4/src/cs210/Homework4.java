package cs210;
import java.util.Scanner;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.lang.Math;
public abstract class Homework4 {
	public static void main(String[] args) throws URISyntaxException, IOException {
		
		Scanner newSc = new Scanner(System.in);
		//boolean retry = true;
		/*
		 * boolean moveForward = false; int version = 0; if (version >= 1) { while
		 * (moveForward == false){ System.out.println("Continue? 1/0"); String input =
		 * newSc.nextLine(); input.toLowerCase(); if (input == "1") {
		 * System.out.println("Sounds Good"); }else if(input == "0"){
		 * System.out.println("Goodbye"); retry= false; }else {
		 * System.out.println("What was that?"); }}}
		 */
		int nr = 0;
		int dr = 0;
	//	version+=1;
		boolean moveOn = false;
		int con = 0;
		//while (retry == true) {
		URI uri= new URI("https://www.youtube.com/watch?v=eaEMSKzqGAg");
		java.awt.Desktop.getDesktop().browse(uri);
		System.out.println("Welcome to Ben Co's Fraction Calculator!!!");
		while (moveOn == false) {
		System.out.println("Please insert Numerator");
		String numerator = newSc.next();
		try {
			int ntor = Integer.parseInt(numerator);
			nr = ntor;
			con = 1;
		}catch(Exception numberformat){
			System.out.println("Numerator Invalid!");
			con = 0;
		}finally {
			if (con == 1){
				break;
			}
		}
		}
		moveOn = false;
		while (moveOn == false) {
			System.out.println("Please insert Denominator");
			String denominator = newSc.next();
			try {
				int dtor = Integer.parseInt(denominator );
				dr = dtor;
				try {
					int wholeNum = nr / dr;
					con = 1;
				}catch(Exception divideByZero) {
					double num = Math.random() * 10;
					int num1 = (int) num;
					
					if ((num1 == 1) || (num1 == 2)) {
					URI e= new URI("https://www.youtube.com/watch?v=Q2Me3MJd130");
					System.out.println("Don't try it!");
					java.awt.Desktop.getDesktop().browse(e);
					con = 0;
					}else if((num1 == 3) || (num1 == 4)) {
					URI e= new URI("https://www.youtube.com/watch?v=WWaLxFIVX1s");
					System.out.println("Don't try it!");
					java.awt.Desktop.getDesktop().browse(e);
					con = 0;	
					}else if((num1 == 5) || (num1 == 6)) {
					URI e= new URI("https://www.youtube.com/watch?v=5GfOlP8FKt0");
					System.out.println("Don't try it!");
					java.awt.Desktop.getDesktop().browse(e);
					con = 0;	
					}else if((num1 == 7) || (num1 == 8)) {
					URI e= new URI("https://www.youtube.com/watch?v=5GfOlP8FKt0");
					System.out.println("Don't try it!");
					java.awt.Desktop.getDesktop().browse(e);
					con = 0;	
					}else {
					URI e= new URI("https://www.youtube.com/watch?v=Pw2sex1mJNI");
					System.out.println("Don't try it!");
					java.awt.Desktop.getDesktop().browse(e);
					con = 0;	
					}
					}
					
			}catch(Exception numberformat){
				System.out.println("Denominator Invalid!");
				con = 0;
			}finally {
				if (con == 1){
					break;
				}
			}
		}
		int status = 0;
		if (nr < dr) {
			status = 1;
		}
		if (nr>dr) {
			
			if ((nr%dr)==0){
				status =3;
			}else {
				status = 2;
			}
		}
		switch(status) {
		case 1:
			//6 / 7 is a proper fraction 
			System.out.println(nr + " / " + dr +" is a proper fraction");
			break;
		case 2: 
			//16 / 3 is an improper fraction and its mixed fraction is 5 + 1 / 3.
			int remainder = nr % dr;
			int wholeNum = nr / dr;
			
		
			
			System.out.println(nr + " / " + dr +" is a improper fraction and its mixed fraction is "+ wholeNum + " + "+ remainder+ " / "+ dr);
			break;
		case 3:
			//6 / 2 is an improper fraction and it can be reduced to 3
			int wNum = nr / dr;
			System.out.println(nr + " / " + dr +" is a improper fraction and it can be reduced to "+ wNum);
			break;
		}
		
		}
	
	
	
	//}
}
