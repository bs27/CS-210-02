package cs210;

public abstract class IncrementTest {

	public static void main(String[] args) {
		int i = 10;
		int newNum = 10 * i++;
		
		System.out.println(newNum);


}
}//the plan apptimal cornhole events clu royal court donate buisness
