package cs210;

public class Lottery {

}
