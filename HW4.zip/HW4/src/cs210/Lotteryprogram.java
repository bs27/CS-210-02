package cs210;
import java.math.*;
import java.util.Scanner;
public abstract class Lotteryprogram {

	public static void main(String[] args) {
		Scanner newSc = new Scanner(System.in);
		int numberOne = (int) (Math.random() *10);
		int numberTwo = (int) (Math.random() *10);
		System.out.print(numberOne);
		System.out.print(numberTwo);
		System.out.println("Hey you poor fuck, thanks for playing the lottery you LOSER, what's your first number");
		int input= newSc.nextInt();
		System.out.println("What's your Secound number");
		int input2= newSc.nextInt();
		if ((numberOne == input)&&(numberTwo == input2)){
			
			System.out.print("You Win 10000");
		}else if ((numberOne == input2)&&(numberTwo == input)){
			
			System.out.print("You Win 3000");
		}else if(((numberOne == input2) || (numberOne == input)) || ((numberTwo == input2) || (numberTwo == input))){
			System.out.print("You Win 1000");
		}else {
			System.out.println("You Suck");
			System.out.println();
		}
		

	}

}
