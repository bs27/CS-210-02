package cs210;
import java.util.Scanner; 
public abstract class SumDigits {

	public static void main(String[] args) {
		Scanner newSc = new Scanner(System.in);
		System.out.print("Give me A NUMBER FAM!");
		int input = newSc.nextInt();
		int numOne = input % 1000;
		
		int numTwo = numOne % 100;
		int numThree = numTwo % 10;
		int numFour = numThree % 1;
		int a = input / 1000;
		int b = numOne / 100;
		int c = numTwo / 10;
		int d = numThree / 1;
		int numResult = numOne + numTwo + numThree + numFour;
		System.out.println("Result : " + numResult);
		
		
		
		
	}

}
