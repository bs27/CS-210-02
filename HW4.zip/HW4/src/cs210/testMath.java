package cs210;
import java.awt.Desktop;
import java.math.*; // mass import
import java.util.Scanner;//just want scanner

public abstract class testMath {

	public static void main(String[] args) {
		int i = 1;
		while (i == 1) {
		Scanner newSc = new Scanner(System.in);
		double num1 = (Math.random() * 10.0) ;
		int numOne = (int)num1;
		double num2 = (Math.random() * 10.0) ;
		int numTwo = (int)num2;
		int answer = numOne - numTwo;
		System.out.print("Question: "+numOne+"-"+numTwo+"= ?");
		int benAnswer = newSc.nextInt();
		if (benAnswer == answer) {
			System.out.println("Correct");
		}else {
			System.out.println("Incorrect");
			

			
	        
		}}
	}}

