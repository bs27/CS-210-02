package cs210;
import java.util.Scanner;
public abstract class twoNumber {

	public static void main(String[] args) {
		Scanner newSc = new Scanner(System.in);
		int number = newSc.nextInt();
		int num1 = number%10; 
		int num2 = number/10;
		if (num1 > num2){
			System.out.println(num1 +"Is greater");
		}else if (num2 > num1) {
			System.out.println(num2);
		}else {
			System.out.println("Numbers are the same");
		}
			
		

	}

}
