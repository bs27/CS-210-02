package cs210;
import java.util.Scanner;
import java.math.*;
public abstract class volofcylinder {
	//input 
	//processing

	public static void main(String[] args) {
		Scanner newSc = new Scanner(System.in);
		System.out.println("Hey Stupid! Can't do Geomentry?");
		System.out.println("Let's Fix that!");
		System.out.println("Insert Radius: ");
		double radius = newSc.nextDouble();
		System.out.println("Insert Height: ");
		double height = newSc.nextDouble();
		final double PI = 3.14;
		double volume = PI*(radius*radius)*height;
		double area = radius * radius * PI;
		System.out.println("Volume = " + volume);
		System.out.println("Area = " + area);
		

	}
}

