package cs210;

import java.util.Scanner;

public abstract class HW5 {
	public static double roundToHundreth(double pureNum) {

		int wholeNum = (int)pureNum;
		double num = (double)wholeNum;
		double decimal = (double)(pureNum - wholeNum);
		double decimal2 = Math.round((decimal * 100));
		double roundedAnswer = num + (decimal2/100);
		return roundedAnswer;
		}

	public static void main(String[] args) {
		System.out.println("Welcome to Ben.co's Math Pratice Machine!");
		Scanner newSc = new Scanner(System.in);
		boolean moveOn = false;
		String diff = null;
		String type = null;
		System.out.println("Would you like a (Simple, Medium or Hard) problem?");
		while (moveOn == false) {
		diff = newSc.next();
		diff = diff.trim();
		diff = diff.toUpperCase();
		if (diff.equals("SIMPLE")){
				moveOn = true;
		}else if(diff.equals("MEDIUM")){
			moveOn = true;
		}else if(diff.equals("HARD")){
			moveOn = true;
		}else {
			System.out.println("Please insert a valid difficulty Level:(Simple, Medium or Hard)");
		}
		}
		moveOn = false;
		System.out.println("What would like to practice today (+, -. /, *, %)?)");
		while (moveOn == false) {
			type = newSc.next();
			type = type.trim();
			type = type.toUpperCase();
			if (type.equals("+")){
					moveOn = true;
			}else if(type.equals("-")){
				moveOn = true;
			}else if(type.equals("*")){
				moveOn = true;
			}else if(type.equals("/")){
				moveOn = true;
			}else if(type.equals("%")){
				moveOn = true;	
			}else {
				System.out.println("Please insert practice type:(+, -. /, *, %)");
			}
			}
		switch(type) {
		case "+":
			switch(diff) {
			case "SIMPLE":
					moveOn = false;
					int answer = 0;
					int total;
					String temp;
					int num1 = (int) (Math.random()*10);
					int num2 = (int) (Math.random()*10);
					while(moveOn == false){
				try {
					System.out.println("(What is the answer to ("+ num1 +" " + type + " "  + num2 + " " +")?");
					answer = newSc.nextInt();
					total = num1 + num2;
					if(total == answer) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+total);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}
				break;
			case "MEDIUM":
				moveOn = false;
				double answerb = 0;
				String tempb;
				int n1 = (int)(Math.random()*10000 - 0) + 0;
				int n2 = (int)(Math.random()*10000 - 0)+ 0;
				double totalb = (n1 + n2)/100.00;
				while(moveOn == false){
				try {
					double num1b = (double) n1/100;
					double num2b =(double) n2/100;
					System.out.println("(What is the answer to ("+ num1b +" " + type + " "  + num2b + " " +")?");
					answerb = newSc.nextDouble();
					if(totalb == answerb) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totalb);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}
				break;
			case "HARD":
				moveOn = false;
				double answer1 = 0;
				double totala;
				int n1a = (int)(Math.random()*100000 - 0) + 0;
				int n2a = (int)(Math.random()*100000 - 0)+ 0;
				double num1a = (double)n1a/100;
				double num2a = (double)n2a/100;
				totala = (n1a + n2a)/100.00;
				while(moveOn == false){
				try {
					System.out.println("(What is the answer to ("+ num1a +" " + type + " "  + num2a + " " +")?");
					answer1 = newSc.nextDouble();

					if(totala == answer1) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totala);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}}
			break;
		case "-":
			switch(diff) {
			case "SIMPLE":
					moveOn = false;
					int answer = 0;
					int total;
					String temp;
					int num1 = (int) (Math.random()*10);
					int num2 = (int) (Math.random()*10);
					while(moveOn == false){
				try {
					System.out.println("(What is the answer to ("+ num1 +" " + type + " "  + num2 + " " +")?");
					answer = newSc.nextInt();
					total = num1 - num2;
					if(total == answer) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+total);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}
				break;
			case "MEDIUM":
				moveOn = false;
				double answerb = 0;
				String tempb;
				int n1 = (int)(Math.random()*10000 - 0) + 0;
				int n2 = (int)(Math.random()*10000 - 0)+ 0;
				double totalb = (n1 - n2)/100.00;
				while(moveOn == false){
				try {
					double num1b = (double) n1/100;
					double num2b =(double) n2/100;
					System.out.println("(What is the answer to ("+ num1b +" " + type + " "  + num2b + " " +")?");
					answerb = newSc.nextDouble();
					if(totalb == answerb) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totalb);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}
				break;
			case "HARD":
				moveOn = false;
				double answer1 = 0;
				double totala;
				int n1a = (int)(Math.random()*100000 - 0) + 0;
				int n2a = (int)(Math.random()*100000 - 0)+ 0;
				double num1a = (double)n1a/100;
				double num2a = (double)n2a/100;
				totala = (n1a - n2a)/100.00;
				while(moveOn == false){
				try {
					System.out.println("(What is the answer to ("+ num1a +" " + type + " "  + num2a + " " +")?");
					answer1 = newSc.nextDouble();
					
					if(totala == answer1) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totala);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}}
			break;
		case "*":
			switch(diff) {
			case "SIMPLE":
					moveOn = false;
					int answer = 0;
					int total;
					String temp;
					int num1 = (int) (Math.random()*10);
					int num2 = (int) (Math.random()*10);
					while(moveOn == false){
				try {
					System.out.println("(What is the answer to ("+ num1 +" " + type + " "  + num2 + " " +")?\"");
					answer = newSc.nextInt();
					total = num1 * num2;
					if(total == answer) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+total);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}
				break;
				// Tis Good
			case "MEDIUM":
				moveOn = false;
				double answerb = 0;
				String tempb;
				int n1 = (int)(Math.random()*10000 - 0) + 0;
				int n2 = (int)(Math.random()*10000 - 0)+ 0;
				double num1b = (double) n1/100;
				double num2b =(double) n2/100;
				double totalb = (double)(num1b * num2b);
				totalb = roundToHundreth(totalb);
				while(moveOn == false){
				try {
					
					System.out.println("(What is the answer to ("+ num1b +" " + type + " "  + num2b + " " +")? ");
					answerb = newSc.nextDouble();
					if(totalb == answerb) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totalb);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}
				break;
			case "HARD":
				moveOn = false;
				double answer1 = 0;
				double totala;
				int n1a = (int)(Math.random()*100000 - 0) + 0;
				int n2a = (int)(Math.random()*100000 - 0)+ 0;
				double num1a = (double)n1a/100;
				double num2a = (double)n2a/100;
				totala = num1a * num2a;
				totala = roundToHundreth(totala);
				while(moveOn == false){
				try {
					System.out.println("(What is the answer to ("+ num1a +" " + type + " "  + num2a + " " +")?");
					answer1 = newSc.nextDouble();
					
					if(totala == answer1) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totala);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}}
			break;
		case "/":
			switch(diff) {
			case "SIMPLE":
					moveOn = false;
					int answer = 0;
					int total;
					String temp;
					int num1 = (int) (Math.random()*10);
					int num2 = (int) (Math.random()*10);
					while(moveOn == false){
				try {
					System.out.println("(What is the answer to ("+ num1 +" " + type + " "  + num2 + " " +")? "
							+ "Hint: Answer is integer without the remainder or decimal equilvalent");
					answer = newSc.nextInt();
					total = num1 / num2;
					if(total == answer) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+total);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Valid Number!");
			}
				}
				break;
			case "MEDIUM":
				moveOn = false;
				double answerb = 0;
				String tempb;
				int n1 = (int)(Math.random()*10000 - 0) + 0;
				int n2 = (int)(Math.random()*10000 - 0)+ 0;
				double num1b = (double) n1/100;
				double num2b =(double) n2/100;
				double totalb = ((double)num1b / num2b);
				totalb = roundToHundreth(totalb);
				while(moveOn == false){
				try {
					
					System.out.println("(What is the answer to ("+ num1b +" " + type + " "  + num2b + " " +")? ");
					answerb = newSc.nextDouble();
					if(totalb == answerb) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totalb);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}
				break;
			case "HARD":
				moveOn = false;
				double answer1 = 0;
				double totala;
				int n1a = (int)(Math.random()*100000 - 0) + 0;
				int n2a = (int)(Math.random()*100000 - 0)+ 0;
				double num1a = (double)n1a/100;
				double num2a = (double)n2a/100;
				totala = ((double)num1a / num2a);
				totala = roundToHundreth(totala);
				while(moveOn == false) {
				try {
					System.out.println("(What is the answer to ("+ num1a +" " + type + " "  + num2a + " " +")?");
					answer1 = newSc.nextDouble();
					
					if(totala == answer1) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totala);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}}
			break;
		case "%":
			switch(diff) {
			case "SIMPLE":
					moveOn = false;
					int answer = 0;
					int total;
					String temp;
					int num1 = (int) (Math.random()*10);
					int num2 = (int) (Math.random()*10);
					while(moveOn == false){
				try {
					System.out.println("(What is the answer to ("+ num1 +" " + type + " "  + num2 + " " +")?");
					answer = newSc.nextInt();
					total = num1 % num2;
					if(total == answer) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+total);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}
				break;
			case "MEDIUM":
				moveOn = false;
				double answerb = 0;
				String tempb;
				int n1 = (int)(Math.random()*10000 - 0) + 0;
				int n2 = (int)(Math.random()*10000 - 0)+ 0;
				double totalb = (n1 % n2)/100.00;
				while(moveOn == false){
				try {
					double num1b = (double) n1/100;
					double num2b =(double) n2/100;
					System.out.println("(What is the answer to ("+ num1b +" " + type + " "  + num2b + " " +")?");
					answerb = newSc.nextDouble();
					if(totalb == answerb) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totalb);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}
				break;
			case "HARD":
				moveOn = false;
				double answer1 = 0;
				double totala;
				int n1a = (int)(Math.random()*100000 - 0) + 0;
				int n2a = (int)(Math.random()*100000 - 0)+ 0;
				double num1a = (double)n1a/100;
				double num2a = (double)n2a/100;
				totala = (n1a % n2a)/100.00;
				while(moveOn == false){
				try {
					System.out.println("(What is the answer to ("+ num1a +" " + type + " "  + num2a + " " +")?");
					answer1 = newSc.nextDouble();
					
					if(totala == answer1) {
					System.out.println("Good job your answer is correct!");
					moveOn = true;
					}else {
					System.out.println("Your answer is wrong, the correct answer should be "+totala);
					moveOn = true;
					}
			}catch(Exception e) {
			temp = newSc.nextLine();
			System.out.println("Please insert a Number!");
			}
				}}
			break;
	}
			
		//Would you like (Simple, Medium or Hard) problem? Medium
		//What would like to practice today (+, -. /, *, %)? +
		//What is the answer to (45.03 + 5.03)? 50.06
		//Good job your answer is correct! or Your answer is wrong, the correct answer should be 152004.35!
		// Write a program that prompts the user to select one of these Math practices categories (Simple, Medium, Hard). 
		//Then promote the user to select one of these arithmetic operation (+, -, /, *, %) that they want to practice. 
		//For Simple selection generate two random integer numbers between 0 to +10, 
		//for Medium selection generate two double precision numbers between 0.00 to 100.00 and 
		//for Hard selection generate two double precision numbers between 0.00 to 1000.00. 
		//Show the problem statement to the user and ask them for the answer then check if their 
		//answer is correct or not correct and output the proper output to them.
		// Use Switch
		
	}}


