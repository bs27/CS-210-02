package cs210;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
public abstract class HW6 {
	/*
	 * static TimerTask task = new TimerTask() { public void run() { if( .equals("")
	 * ) { System.out.println( "you input nothing." ); System.exit( 0 ); } } };
	 */
	/*Enter a City name that contains L: Los Angeles
	Enter a Country that contains L: Libya 
	Enter a Name that contains L: Lorry 
	Enter an Animal that contains L: Lizard
	Enter a Food that contains L: Lasagna  
	*/
	// make syre one letter worlds srvie
	public static void main(String[] args) {
	Scanner newSc = new Scanner(System.in);
	char randomLetter = generateRandomLetter();
	int totalScore = 0 ;
	System.out.println("Welcome to Ben Sottile's Speed Game!");
	instructionsGet();
//	boolean userAnswer = engageChronoRushMode();
//	if(userAnswer = true) {
	System.out.println("-----------Game Start-----------");
//	Timer timer = new Timer();
	System.out.println("Enter a City name that contains " + randomLetter +": ");
//	timer.schedule( task, 10*1000 );
	String city = newSc.nextLine();
//	timer.cancel();
	System.out.println("Enter a Country that contains " + randomLetter +": ");
	String country = newSc.nextLine();
	System.out.println("Enter a Name that contains " + randomLetter +": ");
	String name = newSc.nextLine();
	System.out.println("Enter a Animal that contains " + randomLetter +": ");
	String animal = newSc.nextLine();
	System.out.println("Enter a Food that contains " + randomLetter +": ");
	String food = newSc.nextLine();
	totalScore = evaluateScore(city, randomLetter, totalScore);
	totalScore = evaluateScore(country, randomLetter, totalScore);
	totalScore = evaluateScore(name, randomLetter,totalScore);
	totalScore = evaluateScore(animal, randomLetter,totalScore);
	totalScore = evaluateScore(food, randomLetter,totalScore);
	System.out.println("Game Over: You Scored "+ totalScore + "/50!");
		/*
		 * // }else { System.out.println("-----------Game Start-----------");
		 * System.out.println("Enter a City name that contains " + randomLetter +": ");
		 * String city = newSc.nextLine();
		 * System.out.println("Enter a Country that contains " + randomLetter +": ");
		 * String country = newSc.nextLine();
		 * System.out.println("Enter a Name that contains " + randomLetter +": ");
		 * String name = newSc.nextLine();
		 * System.out.println("Enter a Animal that contains " + randomLetter +": ");
		 * String animal = newSc.nextLine();
		 * System.out.println("Enter a Food that contains " + randomLetter +": ");
		 * String food = newSc.nextLine(); totalScore = evaluateScore(city,
		 * randomLetter, totalScore); totalScore = evaluateScore(country, randomLetter,
		 * totalScore); totalScore = evaluateScore(name, randomLetter,totalScore);
		 * totalScore = evaluateScore(animal, randomLetter,totalScore); totalScore =
		 * evaluateScore(food, randomLetter,totalScore);
		 * System.out.println("Game Over: You Scored "+ totalScore + "/50!");
		 */
	}
	
	
	public static boolean engageChronoRushMode() {
		boolean x = true;
		boolean choice = false;
		Scanner newSc = new Scanner(System.in);
		while(true==x) {
			System.out.println("Would you to play ChronoRush Mode? (You are only allowed 10 secounds to answer.) Type Yes or No");
			String instrucInput = newSc.nextLine();
			instrucInput = instrucInput.toLowerCase();
			if(instrucInput.contains("yes")){
				System.out.println("Hmm, its a challenge then!");
				x = false;
				choice = true;
				return choice;
			}else if(instrucInput.contains("no")) {
				System.out.println("Loser!");
				x = false;
				choice = false;
				return choice;
			}else {
				System.out.println("Huh?");
			}
			}
		return choice;
	}

	public static int evaluateScore(String word, char randomLetter, int totalScore) {
		int length = word.length();
		word = word.toUpperCase();
		char beginningLetter = word.charAt(0);
		char middleLetter = word.charAt(length/2);
		char endLetter = word.charAt(length - 1);
		if( length < 2 ) {
			return totalScore;
		}
		if(randomLetter == beginningLetter) {
			totalScore += 10;
			return totalScore;
		}else if(randomLetter == middleLetter) {
			totalScore += 5;
			return totalScore;
		}else if(randomLetter == endLetter) {
			totalScore += 2;
			return totalScore;
		}else {
			return totalScore ;
		}
	}

	public static char generateRandomLetter() {
		int randomNum = (int)((Math.random() * 26)+ 65);
		char randomLetter = (char) randomNum;
		return randomLetter;
 }
	public static void instructionsGet(){
		Scanner newSc = new Scanner(System.in);
		boolean x = true;
		while(true==x) {
		System.out.println("Would you like to hear the rules? Type Yes or No");
		String instrucInput = newSc.nextLine();
		instrucInput = instrucInput.toLowerCase();
		if(instrucInput.contains("yes")){
			System.out.println("Enter a word for a City, Food, a person Name, Country, and Animal ");
			System.out.println("which contains the Letter displayed.");
			x = false;
		}else if(instrucInput.contains("no")) {
			System.out.println("Alright, then let's get started!");
			x = false;
		}else {
			System.out.println("Huh?");
		}
		}
 }
}
