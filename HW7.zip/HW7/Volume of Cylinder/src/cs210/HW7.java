package cs210;

import java.util.ArrayList;
import java.util.Scanner;
import java.math.*;

public abstract class HW7 {
	/*
	 * }else if((Character.toString(userInput.charAt(i+1)) == "!")) { double fire =
	 * (double)Integer.parseInt(s); double total = 1; for(int x = (int) fire; 0 < x;
	 * x--) { total = total * x; } nums.add(fire); }else {
	 * 
	 * double fire = (double)Integer.parseInt(s); nums.add(fire);
	 * 
	 * 
	 * }
	 */
	public static void main(String[] args) {
		String s = "";
		String z = "";
		String userInput;
		Scanner newSc = new Scanner(System.in);
		// Opening
		System.out.println("Welcome to Ben's Calculator");
		boolean con = false;
		boolean con3 = false;
		ArrayList<String> operations = new ArrayList<String>();
		ArrayList<Double> nums = new ArrayList<Double>();
		while (con3 == false) {
			con = false;
			while (con == false) {
				System.out.println(
						"Please insert calculation as a line of text seperated by operation symbols (+ - * / ^x) and type = when your ready to calcualte");
				// Input
				userInput = newSc.next();
				for (int i = 0; i <= userInput.length() - 1; i++) {
					//
					try {

						if (Character.toString(userInput.charAt(i)).contains("+")
								|| Character.toString(userInput.charAt(i)).contains("-")
								|| Character.toString(userInput.charAt(i)).contains("/")
								|| Character.toString(userInput.charAt(i)).contains("*")
								|| Character.toString(userInput.charAt(i)).contains("=")
								|| Character.toString(userInput.charAt(i)).contains("^")
								|| Character.toString(userInput.charAt(i)).contains("s")) {
							if ((Character.toString(userInput.charAt(i)).contains("^"))) {
								i = i + 1;
								while (Character.toString(userInput.charAt(i)).contains("0")
										|| Character.toString(userInput.charAt(i)).contains("1")
										|| Character.toString(userInput.charAt(i)).contains("2")
										|| Character.toString(userInput.charAt(i)).contains("3")
										|| Character.toString(userInput.charAt(i)).contains("4")
										|| Character.toString(userInput.charAt(i)).contains("5")
										|| Character.toString(userInput.charAt(i)).contains("6")
										|| Character.toString(userInput.charAt(i)).contains("7")
										|| Character.toString(userInput.charAt(i)).contains("8")
										|| Character.toString(userInput.charAt(i)).contains("9")) {

									String d = Character.toString(userInput.charAt(i));
									int y = Integer.parseInt(d);
									z = z + Integer.toString(y);
									i = i + 1;
								}
								double fire1 = Math.pow((double) Integer.parseInt(s), (double) Integer.parseInt(z));
								nums.add(fire1);

							} /*
								 * else if(Character.toString(userInput.charAt(i)).contains("s")) { i = i + 1;
								 * if(Character.toString(userInput.charAt(i)).contains("q")) { i = i + 1;
								 * if(Character.toString(userInput.charAt(i)).contains("r")) { i = i + 1;
								 * if(Character.toString(userInput.charAt(i)).contains("t")) { i = i + 1;
								 * while(Character.toString(userInput.charAt(i)).contains("0")||Character.
								 * toString(userInput.charAt(i)).contains("1")||Character.toString(userInput.
								 * charAt(i)).contains("2")||Character.toString(userInput.charAt(i)).contains(
								 * "3")||Character.toString(userInput.charAt(i)).contains("4")||Character.
								 * toString(userInput.charAt(i)).contains("5")||Character.toString(userInput.
								 * charAt(i)).contains("6")||Character.toString(userInput.charAt(i)).contains(
								 * "7")||Character.toString(userInput.charAt(i)).contains("8")||Character.
								 * toString(userInput.charAt(i)).contains("9")) { String d =
								 * Character.toString(userInput.charAt(i)); int y = Integer.parseInt(d); z = z +
								 * Integer.toString(y); i = i + 1; } double fire2 =
								 * Math.sqrt((double)Integer.parseInt(s)); nums.add(fire2); } }
								 * 
								 * } }
								 */else {
								double fire = (double) Integer.parseInt(s);
								nums.add(fire);
							}
							s = "";
							z = "";
							operations.add(Character.toString(userInput.charAt(i)));
							if (Character.toString(userInput.charAt(i)).contains("=")) {
								con = true;
								break;
							}
						} else {
							String f = Character.toString(userInput.charAt(i));
							int a = Integer.parseInt(f);
							s = s + Integer.toString(a);
						}
					} catch (Exception e) {
						System.out.println("Invalid Input");
						nums.clear();
						operations.clear();
						break;
					}
				}
			}
			ArrayList<String> numCalc = new ArrayList<String>();
			double result;
			while (!(operations.get(0).equals("="))) {
				numCalc = nextCalc(numCalc, operations, nums);
				switch (numCalc.get(0)) {
				case "+":
					result = addition(Double.valueOf(numCalc.get(1)), Double.valueOf(numCalc.get(2)));
					nums.set(Integer.valueOf(numCalc.get(3)), result);
					int sa = Integer.valueOf(numCalc.get(4));
					nums.remove(sa);
					int sb = Integer.valueOf(numCalc.get(3));
					operations.remove(sb);
					numCalc.clear();
					break;
				case "-":
					result = subtraction(Double.valueOf(numCalc.get(1)), Double.valueOf(numCalc.get(2)));
					nums.set(Integer.valueOf(numCalc.get(3)), result);
					int sc = Integer.valueOf(numCalc.get(4));
					nums.remove(sc);
					int sd = Integer.valueOf(numCalc.get(3));
					operations.remove(sd);
					numCalc.clear();
					break;
				case "*":
					result = multiplication(Double.valueOf(numCalc.get(1)), Double.valueOf(numCalc.get(2)));
					nums.set(Integer.valueOf(numCalc.get(3)), result);
					int se = Integer.valueOf(numCalc.get(4));
					nums.remove(se);
					int sq = Integer.valueOf(numCalc.get(3));
					operations.remove(sq);
					numCalc.clear();
					break;
				case "/":
					result = division(Double.valueOf(numCalc.get(1)), Double.valueOf(numCalc.get(2)));
					nums.set(Integer.valueOf(numCalc.get(3)), result);
					int sw = Integer.valueOf(numCalc.get(4));
					nums.remove(sw);
					int st = Integer.valueOf(numCalc.get(3));
					operations.remove(st);
					numCalc.clear();
					break;
				case "=":
					break;
				}

			}
			System.out.println(nums.get(0));

			boolean con2 = false;
			while (con2 == false) {
				System.out.println("Type AC to restart or EXIT to stop.");
				String userResponse = newSc.next();
				userResponse = userResponse.toUpperCase();
				if (userResponse.contains("AC")) {
					operations.clear();
					nums.clear();
					break;
				} else if (userResponse.contains("EXIT")) {
					con2 = true;
					con3 = true;
					System.out.println("Goodbye, Have a Nice Day!");
				} else {
					System.out.println("Invalid Input");
				}
			}
		}

	}

	private static double division(Double valueOf, Double valueOf2) {

		return ((double) valueOf / valueOf2);
	}

	private static double multiplication(Double valueOf, Double valueOf2) {

		return ((double) valueOf * valueOf2);
	}

	private static double subtraction(Double valueOf, Double valueOf2) {
		return ((double) valueOf - valueOf2);
	}

	private static double addition(Double valueOf, Double valueOf2) {

		return ((double) valueOf + valueOf2);
	}

	public static ArrayList<String> nextCalc(ArrayList<String> numCalc, ArrayList<String> operations,
			ArrayList<Double> nums) {
		for (int i = 0; i <= operations.size() - 1; i++) {
			if (operations.get(i).equals("*") || operations.get(i).equals("/")) {
				if (operations.get(i).equals("*")) {
					numCalc.add("*");
				}
				if (operations.get(i).equals("/")) {
					numCalc.add("/");
				}
				numCalc.add(String.valueOf(nums.get(i)));
				numCalc.add(String.valueOf(nums.get(i + 1)));
				numCalc.add(String.valueOf((i)));
				numCalc.add(String.valueOf((i + 1)));
				return numCalc;
			}
		}
		for (int i = 0; i <= operations.size() - 1; i++) {
			if (operations.get(i).equals("+") || operations.get(i).equals("-")) {
				if (operations.get(i).equals("+")) {
					numCalc.add("+");
				}
				if (operations.get(i).equals("-")) {
					numCalc.add("-");
				}
				numCalc.add(String.valueOf(nums.get(i)));
				numCalc.add(String.valueOf(nums.get(i + 1)));
				numCalc.add(String.valueOf((i)));
				numCalc.add(String.valueOf((i + 1)));
				return numCalc;
			}
		}
		for (int i = 0; i <= operations.size() - 1; i++) {
			if (operations.get(i).equals("=")) {
				numCalc.add("=");
				return numCalc;
			}

		}
		return null;

	}

}
