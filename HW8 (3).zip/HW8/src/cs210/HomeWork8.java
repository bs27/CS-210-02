package cs210;
//Welcome people 

//generate board based on input
//randomze space 
//generate invalid ints

public abstract class HomeWork8 {

	public static void main(String[] args) {
		System.out.println("Welcome to Eight Queen's. Let us see who is better. I will go first.");
		int[][] myQueens = { { -1, -1, -1, -1, -1, -1, -1, -1 }, { -1, -1, -1, -1, -1, -1, -1, -1 } };
		boolean[][] openSpaces = { { true, true, true, true, true, true, true, true },
				   { true, true, true, true, true, true, true, true }, 
				   { true, true, true, true, true, true, true, true },
				   { true, true, true, true, true, true, true, true }, 
				   { true, true, true, true, true, true, true, true },
				   { true, true, true, true, true, true, true, true }, 
				   { true, true, true, true, true, true, true, true },
				   { true, true, true, true, true, true, true, true } };
		int queenCount = 0;
		while (true) {
			if (myQueens[0][7] != -1) {
				break;
			}
			int addressRowGuess = ((int) (Math.random() * 8));
			int addressColumnGuess = ((int) (Math.random() * 8));
			
			if ((openSpaces[addressRowGuess][addressColumnGuess]) == false) {
				
				for (int i = 0; i <= 1; i++) {
					for (int y2 = 0; y2 <= 7; y2++) {
						myQueens[i][y2] = -1;
					}
				}
				for (int i = 0; i <= 7; i++) {
					for (int y2 = 0; y2 <= 7; y2++) {
						openSpaces[i][y2] = true;
					}
				}
				queenCount = 0;
				continue;
			} else {
				invalidate(openSpaces, addressRowGuess, addressColumnGuess);
				myQueens[0][queenCount] = addressRowGuess;
				myQueens[1][queenCount] = addressColumnGuess;
				queenCount++;

			}
		}
		String[][] board = { { "| |", "| |", "| |", "| |", "| |", "| |", "| |", "| |" },
				   { "| |", "| |", "| |", "| |", "| |", "| |", "| |", "| |" }, 
				   { "| |", "| |", "| |", "| |", "| |", "| |", "| |", "| |" }, 
				   { "| |", "| |", "| |", "| |", "| |", "| |", "| |", "| |" },  
				   { "| |", "| |", "| |", "| |", "| |", "| |", "| |", "| |" }, 
				   { "| |", "| |", "| |", "| |", "| |", "| |", "| |", "| |" }, 
				   { "| |", "| |", "| |", "| |", "| |", "| |", "| |", "| |" }, 
				   { "| |", "| |", "| |", "| |", "| |", "| |", "| |", "| |" }, };
		
			for (int y2 = 0; y2 < myQueens[0].length; y2++) {
				board[myQueens[0][y2]][myQueens[1][y2]] = "|Q|";
				
			}
		
		for (int i = 0; i < board.length; i++) {
			System.out.println();
			for (int y2 = 0; y2 < board[0].length; y2++) {
				System.out.print(board[i][y2]);
			}
		}
		System.out.println("");
		System.out.println("Hahaha I win !");
	}
	

	public static void invalidate(boolean[][] openSpaces, int addressRow, int addressColumn) {
		for (int i = 0; i < 8; i++) {
			openSpaces[addressRow][i] = false;
		}
		for (int i = 0; i < 8; i++) {
			openSpaces[i][addressColumn] = false;
		}
		int y = addressRow;
		for (int x = addressColumn; x >= 0; x--) {
			try {
				openSpaces[y][x] = false;
			} catch (Exception e) {
				break;
			}

			y--;
		}

		y = addressRow;
		for (int x = addressColumn; x >= 0; x--) {
			try {
				openSpaces[y][x] = false;
			} catch (Exception e) {

				break;
			}
			y++;
		}
		int x = addressColumn;
		int y3 = addressRow;
		try {
			while (true) {
				openSpaces[y3][x] = false;
				x++;
				y3--;
			}
		} catch (Exception e) {

		}
		x = addressColumn;

		for (int y1 = addressRow; y1 <= 7; y1++) {
			try {
				openSpaces[y1][x] = false;
			} catch (Exception e) {
				break;
			}
			x++;
		}

	}

}