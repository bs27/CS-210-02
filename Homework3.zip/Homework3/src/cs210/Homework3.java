package cs210;
import java.util.Scanner;
import java.lang.*; 
class Occupant {
	int index;
	String firstName;
	String lastName;
	Double monthlyRent; 
	Double yearlyRent;
	
	Occupant(){
	int index = 0;
	String firstName = "";
	String lastName = "";
	Double monthlyRent = 0.0; 
	Double yearlyRent = 0.0;
	}
	Occupant(int index2, String fName, String lName, Double mRent) {
		index = index2;
		firstName = fName;
		lastName = lName;
		monthlyRent = mRent; 
		yearlyRent = monthlyRent* 12.0;
	}
	
	public void setRent(double input) {
		monthlyRent = input;
		yearlyRent = monthlyRent * 12.0 ;
	}
	public String getIndex() {
		String indexS = Integer.toString(index);
		return indexS;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getMonthlyRent() {
		String mR = Double.toString(monthlyRent);
		return mR;
	}
	public String getYearlyRent() {
		String yR = Double.toString(yearlyRent);
		return yR;
	}
	public double getMonthlyRentDouble() {
		return monthlyRent;
	}
	public double getYearlyRentDouble() {
		return yearlyRent;
	}
}



public abstract class Homework3 {
	static double calcRentTotal(double r1 , double r2 , double r3 , double r4) {
		return r1 + r2 + r3 + r4;
		}
	static double calcFinTotal(Double yRateTotal, Double taxRate, Double maintanaceRate) {
		double tR = yRateTotal * (taxRate/100.00);
		double mR = yRateTotal * (maintanaceRate/100.00);
		return yRateTotal - (tR + mR);
		}
	
	public static void main(String[] args) {
		int index = 1; 
		String fName = "";
		String lName = "";
		Double mRent = 0.0;
		Double taxRate = 0.0;
		Double maintanaceRate = 0.0;
		Double yRateTotal = 0.0;
		Double mRateTotal = 0.0;
		Double finTotal = 0.0;
		Scanner newSc = new Scanner(System.in);
		System.out.println("Salutations and Greeting, I welcome thou great Lord of the Land, to your humble servant, the appartment complex calculator?");
		System.out.println("Let's caluate the tribute your owed by the peasants my lord, and the bounty your have earned");
		System.out.println("My Lord, What's the first name of PEASANT number " + index + " ?");
		fName = newSc.nextLine(); 
		System.out.println("My Lord, What's the last name of PEASANT number " + index + " ?");
		lName = newSc.next();
		System.out.println("My Lord, What's the amount of tribute that PEASANT number "+ index + " pays?");
		mRent = newSc.nextDouble();
		Occupant o1 = new Occupant(index, fName, lName, mRent); 
		index += 1;
		System.out.println("My Lord, What's the first name of PEASANT number " + index + " ?");
		fName = newSc.next(); 
		System.out.println("My Lord, What's the last name of PEASANT number " + index + " ?");
		lName = newSc.next();
		System.out.println("My Lord, What's the amount of tribute that PEASANT number "+ index + " pays?");
		mRent = newSc.nextDouble();
		Occupant o2 = new Occupant(index, fName, lName, mRent); 
		index += 1;
		System.out.println("My Lord, What's the first name of PEASANT number " + index + " ?");
		fName = newSc.next(); 
		System.out.println("My Lord, What's the last name of PEASANT number " + index + " ?");
		lName = newSc.next();
		System.out.println("My Lord, What's the amount of tribute that PEASANT number "+ index + " pays?");
		mRent = newSc.nextDouble();
		Occupant o3 = new Occupant(index, fName, lName, mRent);
		index += 1;
		System.out.println("My Lord, What's the first name of PEASANT number " + index + " ?");
		fName = newSc.next(); 
		System.out.println("My Lord, What's the last name of PEASANT number " + index + " ?");
		lName = newSc.next();
		System.out.println("My Lord, What's the amount of tribute that PEASANT number "+ index + " pays?");
		mRent = newSc.nextDouble();
		Occupant o4 = new Occupant(index, fName, lName, mRent); 
		index += 1;
		System.out.println("Your Great Greatness, what % of our profit must pay to the sovrienthy in taxes?");
		taxRate = newSc.nextDouble();
		System.out.println("Oh great Lord of the Land, what % of our profit must we expend in maintance?");
		maintanaceRate = newSc.nextDouble();
		mRateTotal = calcRentTotal(o1.getMonthlyRentDouble(), o2.getMonthlyRentDouble(),o3.getMonthlyRentDouble(),o4.getMonthlyRentDouble());
		yRateTotal = calcRentTotal(o1.getYearlyRentDouble(), o2.getYearlyRentDouble(),o3.getYearlyRentDouble(),o4.getYearlyRentDouble());
		
		finTotal = calcFinTotal(yRateTotal, taxRate, maintanaceRate);
		final Object[][] table = new String[5][];
		table[0] = new String[] { "Unit#", "First Name", "Last Name"," Monthly Rent"," Yearly Income"};
		table[1] = new String[] { o1.getIndex(), o1.getFirstName(), o1.getLastName(),"$"+o1.getMonthlyRent(),"$"+o1.getYearlyRent() };
		table[2] = new String[] { o2.getIndex(),  o2.getFirstName(), o2.getLastName(),"$"+o2.getMonthlyRent(),"$"+o2.getYearlyRent() };
		table[3] = new String[] { o3.getIndex(),  o3.getFirstName(), o3.getLastName(),"$"+o3.getMonthlyRent(),"$"+o3.getYearlyRent() };
		table[4] = new String[] { o4.getIndex(),  o4.getFirstName(), o4.getLastName(),"$"+o4.getMonthlyRent(),"$"+o4.getYearlyRent() };
		for (final Object[] row : table) {
		    System.out.format("%15s%15s%15s%15s%15s\n", row);
		}
		

		System.out.println("Total\t\t\t\t\t\t"+"$"+mRateTotal+"\t    $"+yRateTotal);
		System.out.println("Total after deductions ("+maintanaceRate+"%"+" & "+taxRate+"%)\t\t\t\t    "+ "$"+finTotal);

		
		
}}
