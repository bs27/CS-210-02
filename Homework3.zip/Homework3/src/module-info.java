module cs210 {
	requires java.base;
	requires java.logging;
	requires java.prefs;
	
}