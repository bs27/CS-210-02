package com.company;

public class Book extends Circulating_Item{
    Book(String titleG , String authorG, String isbnG, String aqDateG, Integer numG, String dd){
        super(titleG , authorG, isbnG, aqDateG, numG, dd);
        borrower = "Currently Available";
        dateBorrowed ="-";
        dateDue = "-";
        deweyDecimalClassification = dd;
    }
    public void display(){
        System.out.println();
        System.out.print("Book"+ " ");
        System.out.print("Title: " + title+ " ");
        System.out.print("Author: " + author+ " ");
        System.out.print("ISBN: " + isbn+ " ");
        System.out.print("Acquisition Date: " + aqDate+ " ");
        System.out.print("Tracking Number: " + trackingNumber+ " ");
        System.out.println("Dewey Decimal Classification: " + deweyDecimalClassification+ " ");
        System.out.println("Borrower: " + borrower+ " ");
        System.out.println("Date Borrowed: "+ dateBorrowed+ " ");
        System.out.println("Date Due " + dateDue+ " ");

    }
}
