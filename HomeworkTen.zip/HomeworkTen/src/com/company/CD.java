package com.company;

public class CD extends Circulating_Item {
    CD(String titleG , String authorG, String isbnG, String aqDateG, Integer numG, String dd){
        super(titleG , authorG, isbnG, aqDateG, numG, dd);
        borrower = "Currently Available";
        dateBorrowed ="-";
        dateDue = "-";
        deweyDecimalClassification = dd;
    }
    public String Composer = author;

    public void display(){
        System.out.println();
        System.out.print("CD"+ " ");
        System.out.print("Title: " + title+ " ");
        System.out.print("Composer: " + Composer+ " ");
        System.out.print("ISBN: " + isbn+ " ");
        System.out.print("Acquisition Date: " + aqDate+ " ");
        System.out.print("Tracking Number: " + trackingNumber+ " ");
        System.out.println("DeweyDecimalClassification : " + deweyDecimalClassification+ " ");
        System.out.println("Borrower: " + borrower+ " ");
        System.out.println("Date Borrowed: "+ dateBorrowed+ " ");
        System.out.println("Date Due " + dateDue+ " ");

    }

}
