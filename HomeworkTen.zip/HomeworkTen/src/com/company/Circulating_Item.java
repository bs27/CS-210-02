package com.company;

public class Circulating_Item extends Library_Item{
    public String borrower;
    public String dateBorrowed;
    public String dateDue;
    public String deweyDecimalClassification;
    Circulating_Item(){
        super();
        String borrower = "Currently Available";
        String dateBorrowed ="-";
        String dateDue = "-";
        String deweyDecimalClassification ="-";
    }
    Circulating_Item(String titleG , String authorG, String isbnG, String aqDateG, Integer numG, String deweyDecimal){
        super(titleG , authorG, isbnG, aqDateG, numG);
        String borrower = "Currently Available";
        String dateBorrowed ="-";
        String dateDue = "-";
        String deweyDecimalClassification = deweyDecimal;
    }
    Circulating_Item(String titleG , String authorG, String isbnG, String aqDateG, Integer numG, String borrowerG , String dateBorrowedG, String dateDueG , String ddcG){
        super(titleG , authorG, isbnG, aqDateG, numG);
        String borrower = borrowerG;
        String dateBorrowed = dateBorrowedG;
        String dateDue = dateDueG;
        String deweyDecimalClassification = ddcG;
    }
    public void checkIn(){
        borrower = "Currently Available";
        dateBorrowed ="-";
        dateDue = "-";
        deweyDecimalClassification ="-";
    }
    public void checkOut(String borrowerG , String dateBorrowedG, String dateDueG , String ddcG){
        borrower = borrowerG;
        dateBorrowed = dateBorrowedG;
        dateDue = dateDueG;
        deweyDecimalClassification = ddcG;
    }


}
