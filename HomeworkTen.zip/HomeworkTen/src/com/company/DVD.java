package com.company;

public class DVD extends Circulating_Item {
    DVD(String titleG , String authorG, String isbnG, String aqDateG, Integer numG, String dd){
        super(titleG , authorG, isbnG, aqDateG, numG, dd);
        borrower = "Currently Available";
        dateBorrowed ="-";
        dateDue = "-";
        deweyDecimalClassification = dd;
    }
    public String Director = author;
    public void display(){
        System.out.println();
        System.out.print("DVD"+ " ");
        System.out.print("Title: " + title+ " ");
        System.out.print("Director: " + Director+ " ");
        System.out.print("ISBN: " + isbn+ " ");
        System.out.print("Acquisition Date: " + aqDate+ " ");
        System.out.print("Tracking Number: " + trackingNumber+ " ");
        System.out.println("DeweyDecimalClassification : " + deweyDecimalClassification+ " ");
        System.out.println("Borrower: " + borrower+ " ");
        System.out.println("Date Borrowed: "+ dateBorrowed+ " ");
        System.out.println("Date Due " + dateDue+ " ");

    }
}
