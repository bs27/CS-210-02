package com.company;

public class Library_Item {
    public String title;
    public String author;
    public String isbn;
    public String aqDate;
    public int trackingNumber;
    Library_Item(){
        title = "No title given";
        author = "No author name given";
        isbn = "No ISBN given";
        aqDate = "No Acquisition Date given";
        trackingNumber = -1;
    }
    Library_Item(String titleG , String authorG, String isbnG, String aqDateG, Integer numG){
        title = titleG;
        author = authorG;
        isbn = isbnG;
        aqDate = aqDateG;
        trackingNumber = numG;

    }
    private void setTitle(String newTitle){
        title = newTitle;
    }
    private String getTitle(){
        return title;
    }
    private void setAuthor(String newAuthor){
        author = newAuthor;
    }
    private String getAuthor(){
        return author;
    }
    private void setISBN(String ISBN){
        isbn =ISBN;
    }
    private String getISBN(){
        return isbn;
    }
    private String getAqDate(){
        return aqDate;
    }
    private void setAqDate(String newAQ){
        aqDate = newAQ;
    }
    private void setTrackingNumber(Integer newTrack){
        trackingNumber = newTrack;
    }
    private Integer getTrackingNum(){
        return trackingNumber;
    }


}

