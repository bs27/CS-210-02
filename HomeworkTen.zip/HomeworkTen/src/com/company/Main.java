package com.company;
import java.util.ArrayList;
public class Main {

    public static void main(String[] args) {
       // ArrayList<MyObject> list = new ArrayList<MyObject>();
        //MyObject myObject = new MyObject (1, 2, 3);
        ArrayList<Withdrawn_Item> withdrawn_items = new ArrayList<>();
        ArrayList<Reference_Item> reference_items = new ArrayList<>();
        ArrayList<Book> books = new ArrayList<>();
        ArrayList<CD> cds= new ArrayList<>();
        ArrayList<DVD> dvds = new ArrayList<>();
        Withdrawn_Item wI1 = new Withdrawn_Item("The Ben Files", "Ben Sottile", "9780136019701", "4/3/2005", 1);
        Withdrawn_Item wT2 = new Withdrawn_Item("Shabanu: Daughter of the Wind","Suzanne Fisher Staples" ,"9780307977885","5/26/2006",2);
        Reference_Item rI1 = new Reference_Item("The Merriam-Webster Dictionary","Merriam-Webster","9780507966885","12/01/16",3,"References BookShelf");
        Reference_Item rI2 = new Reference_Item("Thesaurus by Merriam-Webste","Merriam-Webster","9780857966885","12/01/16",4,"References BookShelf");
        Book b1 = new Book("The Maze Runner", "James Dashner", "9780136019701", "4/3/2013", 5, "845");
        Book b2= new Book("Ready Player One", "Ernest Cline", "9780137619701", "4/3/2045", 6, "823");
        CD cd1 = new CD("Ben Sottile: The Musical", "James Clark", "N/A", "1/1/01", 7, "782.14");
        CD cd2 = new CD("An Evening With Chris Botti", "Chris Botti", "N/A", "1/1/01", 8, "781.65");
        DVD dvd1 = new DVD("Star Trek: Into Darkness", "J.J. Abrams","N/A", "1/1/19", 9, "N/A");
        DVD dvd2 = new DVD("Star Wars: A New Hope", "George Lucas", "N/A", "3/5/1980", 10, "N/A");
        withdrawn_items.add(wI1);
        withdrawn_items.add(wT2);
        reference_items.add(rI1);
        reference_items.add(rI2);
        books.add(b1);
        books.add(b2);
        cds.add(cd1);
        cds.add(cd2);
        dvds.add(dvd1);
        dvds.add(dvd2);
        System.out.println("Welcome to Ben's BookShelf Library Archive!");
        System.out.println("Please Select one of the bellow functions");
        System.out.println("0 - Exit the Archive");
        System.out.println("1 - Display the Archive");
        System.out.println("2 - Add New Item");
        System.out.println("3 - Delete Item");
        System.out.p




    }

    public static void displayFullArchive(ArrayList<Reference_Item> reference_items, ArrayList<Withdrawn_Item> withdrawn_items, ArrayList<Book> books, ArrayList<DVD> dvds, ArrayList<CD> cds) {
        System.out.println("Full Library Archive");
        System.out.println("Books");
        for(int i = 0; i < books.size();i++ ){
            books.get(i).display();
        }
        System.out.println("CD's");
        for(int i = 0; i < cds.size();i++ ){
            cds.get(i).display();
        }
        System.out.println("DVD's");
        for(int i = 0; i < dvds.size();i++ ){
            dvds.get(i).display();
        }
        System.out.println("Reference Materials");
        for(int i = 0; i < reference_items.size();i++ ){
            reference_items.get(i).display();
        }
        System.out.println("Withdrawn Materials");
        for(int i = 0; i < withdrawn_items.size();i++ ){
            withdrawn_items.get(i).display();
        }
    }
}
