package com.company;

public class Reference_Item extends Library_Item{
    String referenceLocation;
    Reference_Item(){
        super();
        referenceLocation = "No reference location name given";
    }
    Reference_Item(String titleG , String authorG, String isbnG, String aqDateG, Integer numG, String refLoc){
        super(titleG , authorG, isbnG, aqDateG, numG);
        referenceLocation = refLoc;
    }
    public void display(){
        System.out.println();
        System.out.print("Reference Material - "+ " ");
        System.out.print("Reference Location:" + referenceLocation+ " ");
        System.out.print("Title: " + title+ " ");
        System.out.print("Author: " + author+ " ");
        System.out.print("ISBN: " + isbn+ " ");
        System.out.print("Acquisition Date: " + aqDate+ " ");
        System.out.println("Tracking Number: " + trackingNumber+ " ");


    }
}
