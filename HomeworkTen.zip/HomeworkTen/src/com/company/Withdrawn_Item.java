package com.company;

public class Withdrawn_Item extends Library_Item {
    boolean withdrawn;
    Withdrawn_Item(){
        super();
        withdrawn = true;
    }
    Withdrawn_Item(String titleG , String authorG, String isbnG, String aqDateG, Integer numG){
        super(titleG , authorG, isbnG, aqDateG, numG);
        withdrawn = true;

    }
    public boolean getWithdrawn(){
       return withdrawn;
    }
//    private String title;
//    private String author;
//    private String isbn;
//    private String aqDate;
//    private int trackingNumber;
    public void display(){
        System.out.println();
        if (withdrawn){
            System.out.print("WITHDRAWN FROM COLLECTION - ");
        }else {
            System.out.print("This item hasn't been withdrawn");
        }

        System.out.print("Title: " + title+ " ");
        System.out.print("Author: " + author+ " ");
        System.out.print("ISBN: " + isbn+ " ");
        System.out.print("Acquisition Date: " + aqDate+ " ");
        System.out.println("Tracking Number: " + trackingNumber+ " ");
    }

}
// + " ")